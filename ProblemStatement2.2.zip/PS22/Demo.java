package PS22;

import java.util.Scanner;

public class Demo {
	public static void main(String[] args) {

		int i = 1,n= 13 ;
		Scanner obj = new Scanner(System.in); 
		System.out.println("Enter the first no: ");

		int firstTerm = obj.nextInt(); // Read user input
		System.out.println("Enter the Second no: ");
		int secondTerm = obj.nextInt();

		while (i <= 13) {
			System.out.print(firstTerm + " ");

			int nextTerm = firstTerm + secondTerm;
			firstTerm = secondTerm;
			secondTerm = nextTerm;

			i++;
		}
	}
}
