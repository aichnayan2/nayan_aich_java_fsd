package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Dao {
	
	public Connection con=null;
	public Statement st=null;

	public Dao() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb", "root", "root");
		System.out.println("connection established with database");
		st=con.createStatement();
	}
	public HashMap<String, String> checkUser(String username, String password) {
		
		HashMap<String,String> user=null;
		String query="select * from user where username='"+username+"' and password='"+password+"'";
		try {
			ResultSet rs=st.executeQuery(query);
			if(rs.next()) {
				user=new HashMap<>();
				//user.put("name", rs.getString("name"));
				user.put("username",rs.getString("username"));
				//user.put("phno",rs.getString("phno"));
				//user.put("adno",rs.getString("adno"));
			}
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return user;
	}
}
