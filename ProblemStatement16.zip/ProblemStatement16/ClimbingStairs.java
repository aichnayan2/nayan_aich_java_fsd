package ProblemStatement16;

import java.util.Scanner;

public class ClimbingStairs {
	static int climbedStairs(int N) {
		if (N < 2)
			return 1;
		else
			return climbedStairs(N - 1) + climbedStairs(N - 2);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of steps");
		int steps = sc.nextInt();
		System.out.println("The total number of ways to climb " + steps + " stairs is : " + climbedStairs(steps));

	}
}
