package PS12;
import PS12.Rectangle;

public class TestRectangle {
	 public static void main(String args[]) {
	        Rectangle obj1 = new Rectangle();
	        obj1.input();
	        obj1.calculate();
	        obj1.display();
	        System.out.println("");
	        Rectangle obj2 = new Rectangle();
	        obj2.input();
	        obj2.calculate();
	        obj2.display();
	        System.out.println("\n");
	        Rectangle obj3 = new Rectangle();
	        obj3.input();
	        obj3.calculate();
	        obj3.display();
	        System.out.println("\n");
	        Rectangle obj4 = new Rectangle();
	        obj4.input();
	        obj4.calculate();
	        obj4.display();
	        System.out.println("\n");
	        Rectangle obj5 = new Rectangle();
	        obj5.input();
	        obj5.calculate();
	        obj5.display();
	    }
}
