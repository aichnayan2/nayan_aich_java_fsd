package PS31;

public abstract class InstrumentMain {

	public abstract void Play();
}

class Piano extends InstrumentMain {
	public void Play() {
		System.out.println("Piano is playing tan tan tan tan");
	}
}

class Flute extends InstrumentMain {
	public void Play() {
		System.out.println("Flute is playing toot toot toot toot");
	}
}

class Guitar extends InstrumentMain {
	public void Play() {
		System.out.println("Guitar is playing tin tin tin ");
	}
}
