package ProblemStatement11;

import java.util.Scanner;
import java.util.Vector;

public class CoinChange {

	static int deno[] = { 1, 2, 5, 10, 20, 50, 100, 500, 1000 };
	static int n = deno.length;

	static void findMinimun(int v) {	//70
		Vector<Integer> obj = new Vector<>();

		for (int i = n - 1; i >= 0; i--) {	//i=8,7, 6, 5

			while (v >= deno[i]) {	//70>=1000, 70>=500,  70>=100, 70>=50 true, 20>=50
				v -= deno[i];	//v= 70-50= 20, 
				obj.add(deno[i]);	//obj=50
			}
		}

		for (int i = 0; i < obj.size(); i++) {
			System.out.print(obj.elementAt(i)+" ");

		}
		System.out.println("\n The minimum number of currency is " + obj.size());
	}

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the amount");
		int n = obj.nextInt();
		findMinimun(n);
		System.out.print("minimal number of change for " + n + ": ");
		
	}
}
