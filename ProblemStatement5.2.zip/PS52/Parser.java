package PS52;

import java.util.Scanner;

public class Parser {

	public static void main(String[] args) {
		Scanner myObj = new Scanner(System.in);  
	    System.out.println("Enter the expression");
	    String expr = myObj.nextLine();
	    String[] expr2=expr.split("\\s");
	    for(int i=0; i<=expr2.length-1;i++){
				System.out.println(expr2[i]+" ");}
	    //System.out.println(expr2);
	    //String delims = "[+\\-*/\\^ ]+";
	    //String[] tokens = expr.split(delims);
	    //for(int i=0; i<=tokens.length-1;i++){
		//	System.out.println(tokens[i]+" ");
		//}
	}

}
