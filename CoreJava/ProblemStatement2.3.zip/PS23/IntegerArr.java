package PS23;

public class IntegerArr {
	public static void main(String[] args) {
		// Initialize array
		int[] arr = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		int sum = 0;
		int sum1 = 0;
		int min = arr[0];
		// Loop through the array to calculate sum of elements
		for (int i = 0; i <= 14; i++) {
			sum = sum + arr[i];
		}
		arr[15] = sum;

		for (int j = 0; j <= 17; j++) {
			sum1 = sum1 + arr[j];
		}
		int avg = sum1 / 18;
		arr[16] = avg;

		for (int k = 0; k < arr.length; k++) {

			if (arr[k] < min)
				min = arr[k];
		}
		arr[17] = min;

		for (int z = 0; z <= 17; z++) {
			System.out.println(arr[z]);
		}
	}
}
