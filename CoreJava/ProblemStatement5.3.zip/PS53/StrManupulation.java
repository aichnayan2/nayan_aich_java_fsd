package PS53;

import java.util.Scanner;

public class StrManupulation {

    static void RotateString(String str)
    {
        int len = str.length();
      
        StringBuffer ab;
         
        for (int i = 0; i < len; i++)
        {
            ab = new StringBuffer();
             
            int j = i;  
            int k = 0;  
      

            for (int k2 = j; k2 < str.length(); k2++) {
                ab.insert(k, str.charAt(j));
                k++;
                j++;
            }
      

            j = 0;
            while (j < i)
            {
                ab.insert(k, str.charAt(j));
                j++;
                k++;
            }
      
            System.out.println(ab);
        }
    }
     
   
    public static void main(String[] args)
    {
        //String  str = new String("MPHASIS");
    	Scanner myObj = new Scanner(System.in);  
    	System.out.println("Enter the expression");
    	String str = myObj.nextLine();
    	RotateString(str);
    }
}
