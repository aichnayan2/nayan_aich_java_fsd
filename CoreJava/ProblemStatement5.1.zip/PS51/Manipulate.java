package PS51;

public class Manipulate {

	public static void main(String[] args) {
		
		String str="JAVA is Simple";
		
		System.out.println(str.toUpperCase());
		System.out.println( str.toLowerCase());
		
		String str2[]=str.split(" ");
		for(String x:str2){
			System.out.println(x.charAt(0));
		}

		System.out.println("Reversed word:");
		for(int i=str2.length-1; i>=0;i--){
			System.out.println(str2[i]+" ");
		}
		
		
		StringBuilder str3=new StringBuilder(str);
		//String str4=str3.split(" ");
		str3.reverse();
		System.out.println(str3);
		
		System.out.println(str.length());
		
	}

}
